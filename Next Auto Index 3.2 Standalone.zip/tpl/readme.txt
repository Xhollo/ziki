Instead of editing this files i suggest you make a plugin :) it's as easy as 1,2,3
Also if you want to you can share it www.master-land.net or ionutvmi@gmail.com
Open Source makes the world a better place