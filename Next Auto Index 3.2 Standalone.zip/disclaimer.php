<?php
/*
Project Name: Next Auto Index
Project URI: http://wapindex.mirazmac.info
Project Version: 1.0
Licence: GPL v3
*/
## This is a modified version of Master Autoindex. So all source rights goes to ionutvmi ##

include "inc/init.php";

$links[] = mai_img("arr.gif")." Disclaimer";
include "header.php";

echo "<div class='title'>Disclaimer</div><div class='content'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; Please Read The Disclaimer Before Download Anything From $set->name</div>
<div class='content2'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; $set->name is a promotional WAPSITE only, All files placed here are for introducing purpose only.</div>
<div class='content'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; Please, buy original Videos/contents from author or developer site!</div>
<div class='content2'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; If you do not agree to all the terms, please disconnect from this site now itself.</div>
<div class='content'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth</div>
<div class='content2'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; All files found on this site have been collected from various sources across the web and are believed to be in the 'public domain'.</div>
<div class='content'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; All the logos and stuff are the property of their respective owners</div>
<div class='content2'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, Please Contact Us. We will remove it in 24 hour!</div>
<div class='content'><img src='$set->url/tpl/style/images/gdir.gif'/>&nbsp; Downloading at your own risk!!! </div>";

include "footer.php";